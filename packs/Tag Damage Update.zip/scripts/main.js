import { world } from "@minecraft/server";

world.sendMessage("Script initialized");

/**
 * Finds a safe spawn location with solid ground beneath the player
 * @param {object} defaultSpawn - The default spawn coordinates
 * @param {object} dimension - The dimension to check blocks in
 * @param {number} radius - The radius around the spawn point to search
 * @returns {object} - Safe spawn coordinates with proper Y value
 */
function findSafeSpawnLocation(defaultSpawn, dimension, radius = 4) {
  let validLocations = [];

  for (let xOffset = -radius; xOffset <= radius; xOffset++) {
    for (let zOffset = -radius; zOffset <= radius; zOffset++) {
      if (xOffset * xOffset + zOffset * zOffset > radius * radius) continue;

      const x = Math.floor(defaultSpawn.x) + xOffset;
      const z = Math.floor(defaultSpawn.z) + zOffset;

      for (let y = 0; y < 256; y++) {
        try {
          const block = dimension.getBlock({ x, y, z });
          const blockAbove = dimension.getBlock({ x, y: y + 1, z });
          const blockTwoAbove = dimension.getBlock({ x, y: y + 2, z });
          if (
            block &&
            !block.isAir &&
            blockAbove &&
            blockAbove.isAir &&
            blockTwoAbove &&
            blockTwoAbove.isAir
          ) {
            validLocations.push({
              x: x,
              y: y + 1,
              z: z,
            });

            break;
          }
        } catch (error) {
          continue;
        }
      }
    }
  }

  if (validLocations.length > 0) {
    const randomIndex = Math.floor(Math.random() * validLocations.length);
    const chosenLocation = validLocations[randomIndex];

    return {
      x: chosenLocation.x,
      y: chosenLocation.y,
      z: chosenLocation.z,
      dimension: dimension,
    };
  } else {
    return {
      x: defaultSpawn.x,
      y: defaultSpawn.y,
      z: defaultSpawn.z,
      dimension: dimension,
    };
  }
}

world.beforeEvents.playerInteractWithEntity.subscribe((event) => {
  const player = event.player
  const entity = event.target
  if (player.hasTag("deny_interact_armor_stand") && entity.typeId == "minecraft:armor_stand") {
    event.cancel = true
  }
})


world.afterEvents.entityHitEntity.subscribe((event) => {
  const damagingEntity = event.damagingEntity
  const hitEntity = event.hitEntity

  if (hitEntity.typeId === "minecraft:armor_stand" && damagingEntity.typeId === "minecraft:player" && damagingEntity.hasTag("deny_interact_armor_stand")) {
    damagingEntity.addEffect("weakness", 60, {
      amplifier: 255,
      showParticles: false
    })
  }
})


world.afterEvents.dataDrivenEntityTrigger.subscribe((event) => {
  const entity = event.entity;
  const eventId = event.eventId;

  if (entity.typeId === "minecraft:player") {
    if (eventId === "tag:death") {
      const player = entity;
      let spawnpoint = player.getSpawnPoint();

      if (!spawnpoint) {
        const defaultSpawn = world.getDefaultSpawnLocation();
        const overworld = world.getDimension("overworld");

        spawnpoint = findSafeSpawnLocation(defaultSpawn, overworld, 6);
      }

      const { x, y, z, dimension } = spawnpoint;
      player.tryTeleport({ x, y, z }, { dimension });

      if (player.getComponent("health")) {
        const healthComponent = player.getComponent("health");
        healthComponent.resetToMaxValue();
        dimension.runCommand(`effect "${player.nameTag}" saturation 1 255 true`);
        dimension.runCommand(`effect "${player.nameTag}" fire_resistance 2 255 true`);
      }
    }
  }
});
