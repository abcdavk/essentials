import { custom_id_texture } from "./essentials/config";
import { typeIdToID } from "./libs/typeIds";
export function calculateNextValue(level, initial, step) {
    if (level < 1)
        return initial;
    return parseFloat((initial + level * step).toFixed(2));
}
export function itemTypeIdToName(itemtype) {
    const rawName = itemtype.split(":")[1] || itemtype;
    return rawName
        .split("_")
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(" ");
}
export function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
export function generateRandomID(length = 8) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * chars.length);
        result += chars[randomIndex];
    }
    return result;
}
export function truncateWithDots(text, maxLength = 12) {
    return text.length > maxLength ? text.slice(0, maxLength) + "..." : text;
}
const number_of_1_16_100_items = 2;
export function convertTypeIdToAuxIcon(typeId) {
    const ID = typeIdToID.get(typeId);
    if (ID !== undefined) {
        const finalID = ((ID + (ID < 256 ? 0 : number_of_1_16_100_items)) * 65536);
        return `§aaux_item§a${finalID}`;
    }
    const texturePath = custom_id_texture[typeId];
    if (texturePath) {
        return texturePath;
    }
    return 'textures/unknown';
}
