export const custom_id_texture = {
    "dave:admin_menu": "textures/items/admin_menu",
    "lc:protection_block_25": "textures/blocks/protection_block_side",
    "lc:protection_block_50": "textures/blocks/protection_block_side",
    "lc:protection_block_75": "textures/blocks/protection_block_side",
    "lc:protection_block_100": "textures/blocks/protection_block_side",
    "lc:protection_block_250": "textures/blocks/protection_block_side"
};
